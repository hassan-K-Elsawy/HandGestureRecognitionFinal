derived from model 1
Here I changed the neural network and added an additional 50 pictures