derived from model 1
here i change the neural network and don't add the new dataset 